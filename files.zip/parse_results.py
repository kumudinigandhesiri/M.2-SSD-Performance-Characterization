#!/usr/bin/env python3
"""Parse fio JSON output into one tidy CSV.

Reads every ``<rw>_bs<size>_qd<N>[_run<K>].json`` file in a directory, extracts
bandwidth, IOPS and completion-latency statistics, averages repeated runs, and
writes a CSV that ``report.py`` consumes.

Units: bandwidth in MB/s (decimal, as SSD vendors quote), latency in microseconds.

Usage:
    python scripts/parse_results.py results/raw results/summary.csv
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import pandas as pd

NAME_RE = re.compile(r"^(?P<rw>[a-z]+)_bs(?P<bs>\w+)_qd(?P<qd>\d+)(?:_run(?P<run>\d+))?$")
PERCENTILES = {  # CSV column -> key in fio's percentile map
    "lat_p50_us": "50.000000",
    "lat_p90_us": "90.000000",
    "lat_p99_us": "99.000000",
    "lat_p999_us": "99.900000",
    "lat_p9999_us": "99.990000",
}
METRIC_COLS = ["bandwidth_MBps", "iops", "lat_avg_us", *PERCENTILES]


def bs_to_kib(bs: str) -> float:
    """'4k' -> 4, '128k' -> 128, '1m' -> 1024."""
    m = re.fullmatch(r"(\d+)([kKmM]?)", bs)
    if not m:
        raise ValueError(f"cannot parse block size: {bs!r}")
    n, unit = int(m[1]), m[2].lower()
    return float(n * 1024 if unit == "m" else n if unit == "k" else n / 1024)


def load_fio_json(path: Path) -> dict:
    """Load fio JSON, tolerating warning lines that fio prints before the object."""
    text = path.read_text()
    start = text.find("{")
    if start < 0:
        raise ValueError("no JSON object found")
    return json.loads(text[start:])


def _latency_block(side: dict) -> tuple[dict, float]:
    """Return (latency stats dict, scale-to-microseconds) for old and new fio."""
    if "clat_ns" in side:
        return side["clat_ns"], 1 / 1000.0
    if "clat" in side:  # fio < 3.0 reported microseconds
        return side["clat"], 1.0
    raise KeyError("no completion latency block")


def parse_file(path: Path) -> dict | None:
    match = NAME_RE.match(path.stem)
    if not match:
        return None
    data = load_fio_json(path)
    job = data["jobs"][0]
    if job.get("error", 0):
        raise ValueError(f"fio reported error {job['error']}")
    rw = match["rw"]
    side = job["write"] if "write" in rw else job["read"]
    lat, scale = _latency_block(side)
    pct = lat.get("percentile", {})
    row = {
        "workload": rw,
        "block_size": match["bs"],
        "block_size_kib": bs_to_kib(match["bs"]),
        "queue_depth": int(match["qd"]),
        "bandwidth_MBps": side["bw"] * 1024 / 1e6,  # fio reports KiB/s
        "iops": side["iops"],
        "lat_avg_us": lat["mean"] * scale,
        "synthetic": bool(data.get("synthetic", False)),
    }
    for col, key in PERCENTILES.items():
        row[col] = pct[key] * scale if key in pct else float("nan")
    return row


def summarize(raw_dir: Path) -> tuple[pd.DataFrame, list[str]]:
    rows, problems = [], []
    for path in sorted(raw_dir.glob("*.json")):
        if path.name == "run_metadata.json":
            continue
        try:
            row = parse_file(path)
        except Exception as exc:  # report and continue with the other files
            problems.append(f"{path.name}: {exc}")
            continue
        if row is not None:
            rows.append(row)
    if not rows:
        return pd.DataFrame(), problems

    df = pd.DataFrame(rows)
    keys = ["workload", "block_size", "block_size_kib", "queue_depth"]
    grouped = df.groupby(keys, as_index=False)
    out = grouped[METRIC_COLS].mean()
    out["runs"] = grouped.size()["size"].to_numpy()
    out["iops_std"] = grouped["iops"].std().fillna(0.0)["iops"].to_numpy()
    out["synthetic"] = grouped["synthetic"].max()["synthetic"].to_numpy()
    cols = [*keys, "runs", *METRIC_COLS, "iops_std", "synthetic"]
    return out[cols].sort_values(["workload", "block_size_kib", "queue_depth"]), problems


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("raw_dir", nargs="?", default="results/raw", help="directory of fio JSON files")
    ap.add_argument("out_csv", nargs="?", default="results/summary.csv", help="CSV to write")
    args = ap.parse_args(argv)

    raw = Path(args.raw_dir)
    if not raw.is_dir():
        print(f"error: {raw} is not a directory", file=sys.stderr)
        return 2
    df, problems = summarize(raw)
    for p in problems:
        print(f"warning: skipped {p}", file=sys.stderr)
    if df.empty:
        print(f"error: no usable fio JSON files in {raw}", file=sys.stderr)
        return 1
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out_csv, index=False, float_format="%.3f")
    print(f"wrote {len(df)} rows ({int(df['runs'].sum())} runs) to {args.out_csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
