#!/usr/bin/env python3
"""Generate SYNTHETIC fio-format JSON so the toolkit can be tried without a drive.

Every file carries ``"synthetic": true`` and the report shows a banner and a
watermark. These are NOT measurements of any real SSD. The model keeps the
numbers internally consistent (latency follows Little's law: QD / IOPS).

Usage:
    python scripts/make_demo_data.py demo/raw --repeats 3
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

SEQ_PLATEAU_MBPS = {"read": 3500.0, "write": 3000.0}
RAND_PEAK_4K_IOPS = {"randread": 650_000.0, "randwrite": 560_000.0}
SEQ_BS_KIB = 128
RAND_BS_KIB = [4, 16]
QUEUE_DEPTHS = [1, 4, 16, 32]


def point(rw: str, bs_kib: int, qd: int, rng: random.Random) -> dict:
    bs_bytes = bs_kib * 1024
    if rw in SEQ_PLATEAU_MBPS:
        bw_mbps = SEQ_PLATEAU_MBPS[rw] * (1 - math.exp(-qd / 1.5))
        iops = bw_mbps * 1e6 / bs_bytes
    else:
        iops = RAND_PEAK_4K_IOPS[rw] * (4 / bs_kib) ** 0.85 * (1 - math.exp(-qd / 9))
        bw_mbps = iops * bs_bytes / 1e6
    noise = rng.gauss(1.0, 0.015)
    iops *= noise
    bw_mbps *= noise
    mean_ns = qd / iops * 1e9  # Little's law
    tail = 1 + 0.04 * qd
    return {
        "bw": bw_mbps * 1e6 / 1024,  # KiB/s, as fio reports
        "iops": iops,
        "clat_ns": {
            "mean": mean_ns,
            "percentile": {
                "50.000000": mean_ns * 0.92,
                "90.000000": mean_ns * 1.35 * tail ** 0.3,
                "99.000000": mean_ns * 1.9 * tail ** 0.7,
                "99.900000": mean_ns * 3.2 * tail,
                "99.990000": mean_ns * 6.0 * tail * 1.4,
            },
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("out_dir", nargs="?", default="demo/raw")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)
    empty = {"bw": 0, "iops": 0, "clat_ns": {"mean": 0, "percentile": {}}}

    plan = []
    for qd in QUEUE_DEPTHS:
        plan += [("read", SEQ_BS_KIB, qd), ("write", SEQ_BS_KIB, qd)]
        for bs in RAND_BS_KIB:
            plan += [("randread", bs, qd), ("randwrite", bs, qd)]

    for run in range(1, args.repeats + 1):
        for rw, bs, qd in plan:
            side = point(rw, bs, qd, rng)
            job = {"jobname": f"{rw}_{bs}k_qd{qd}", "error": 0,
                   "read": side if "write" not in rw else empty,
                   "write": side if "write" in rw else empty}
            doc = {"fio version": "synthetic-demo", "synthetic": True, "jobs": [job]}
            (out / f"{rw}_bs{bs}k_qd{qd}_run{run}.json").write_text(json.dumps(doc, indent=1))

    (out / "run_metadata.json").write_text(json.dumps({
        "timestamp_utc": "2026-01-01T00:00:00Z", "hostname": "demo-host", "kernel": "demo",
        "fio_version": "synthetic-demo", "target": "/mnt/nvme/fio_testfile (synthetic)",
        "target_type": "file", "size": "4G", "runtime_s": 30, "ramp_s": 5, "seq_bs": "128k",
        "rand_bs": "4k 16k", "queue_depths": "1 4 16 32", "repeats": args.repeats,
        "ioengine": "libaio", "synthetic": True}, indent=2))
    (out.parent / "link_info.json").write_text(json.dumps([{
        "pci_addr": "0000:01:00.0", "model": "DEMO NVMe SSD 1TB (synthetic)",
        "link_cap_speed": "16GT/s", "link_cap_width": "x4",
        "link_sta_speed": "16GT/s", "link_sta_width": "x4",
        "downgraded": False, "temperature_c": 41}], indent=2))
    print(f"wrote synthetic demo data to {out}")


if __name__ == "__main__":
    main()
