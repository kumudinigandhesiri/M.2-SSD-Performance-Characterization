#!/usr/bin/env python3
"""Build plots, a markdown report and a self-contained HTML report from summary.csv.

Usage:
    python scripts/report.py results/summary.csv results/report \
        --link-info results/link_info.json --metadata results/raw/run_metadata.json
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

WL_COLOR = {"read": "#2563eb", "write": "#ea580c", "randread": "#2563eb", "randwrite": "#ea580c"}
WL_LABEL = {"read": "seq read", "write": "seq write", "randread": "rand read", "randwrite": "rand write"}
LINESTYLES = ["-", "--", ":", "-."]
SEQ, RAND = ["read", "write"], ["randread", "randwrite"]
PCT_COLS = [("lat_p50_us", "p50"), ("lat_p90_us", "p90"), ("lat_p99_us", "p99"),
            ("lat_p999_us", "p99.9"), ("lat_p9999_us", "p99.99")]


# ---------------------------------------------------------------- plotting
def _groups(df: pd.DataFrame, workloads: list[str]):
    """Yield (workload, block_size, rows, linestyle) with a style per block size."""
    sub = df[df.workload.isin(workloads)]
    for wl in workloads:
        sizes = sorted(sub[sub.workload == wl].block_size_kib.unique())
        for i, kib in enumerate(sizes):
            g = sub[(sub.workload == wl) & (sub.block_size_kib == kib)].sort_values("queue_depth")
            yield wl, g.block_size.iloc[0], g, LINESTYLES[i % len(LINESTYLES)]


def _new_axes(title: str, xlabel: str, ylabel: str):
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.25)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    return fig, ax


def _save(fig, path: Path, synthetic: bool) -> Path:
    if synthetic:
        fig.text(0.5, 0.5, "SYNTHETIC DEMO DATA", ha="center", va="center", fontsize=30,
                 color="gray", alpha=0.18, rotation=20, fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def _line_plot(df, workloads, metric, title, ylabel, path, synthetic, logy=False, scale=1.0):
    items = list(_groups(df, workloads))
    if not items:
        return None
    fig, ax = _new_axes(title, "Queue depth", ylabel)
    for wl, bs, g, ls in items:
        ax.plot(g.queue_depth, g[metric] * scale, marker="o", ms=4, lw=2, ls=ls,
                color=WL_COLOR[wl], label=f"{WL_LABEL[wl]} {bs}")
    ax.set_xscale("log", base=2)
    ax.set_xticks(sorted(df.queue_depth.unique()))
    ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    if logy:
        ax.set_yscale("log")
    ax.legend(frameon=False, fontsize=9)
    return _save(fig, path, synthetic)


def plot_latency_vs_iops(df, path, synthetic):
    items = list(_groups(df, RAND))
    if not items:
        return None
    fig, ax = _new_axes("Random p99 latency vs throughput", "Throughput (K IOPS)", "p99 latency (us)")
    for wl, bs, g, ls in items:
        ax.plot(g.iops / 1000, g.lat_p99_us, marker="o", ms=4, lw=2, ls=ls,
                color=WL_COLOR[wl], label=f"{WL_LABEL[wl]} {bs}")
        for _, r in g.iterrows():
            ax.annotate(f"QD{int(r.queue_depth)}", (r.iops / 1000, r.lat_p99_us),
                        textcoords="offset points", xytext=(4, 4), fontsize=7, color="gray")
    ax.set_yscale("log")
    ax.legend(frameon=False, fontsize=9)
    return _save(fig, path, synthetic)


def plot_percentiles(df, path, synthetic):
    g = df[df.workload == "randread"]
    if g.empty:
        return None
    g = g[g.block_size_kib == g.block_size_kib.min()]
    g = g[g.queue_depth == g.queue_depth.min()]
    cols = [(c, lab) for c, lab in PCT_COLS if c in g and g[c].notna().all()]
    if g.empty or not cols:
        return None
    row = g.iloc[0]
    fig, ax = _new_axes(f"Latency percentiles: rand read {row.block_size}, QD{int(row.queue_depth)}",
                        "Percentile", "Latency (us)")
    bars = ax.bar([lab for _, lab in cols], [row[c] for c, _ in cols], color="#2563eb", width=0.55)
    ax.bar_label(bars, fmt="%.0f", fontsize=8, padding=2)
    return _save(fig, path, synthetic)


def make_figures(df, out_dir: Path, synthetic: bool) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    figs = {
        "Sequential bandwidth": _line_plot(df, SEQ, "bandwidth_MBps", "Sequential bandwidth vs queue depth",
                                           "MB/s", out_dir / "sequential_bandwidth.png", synthetic),
        "Random IOPS": _line_plot(df, RAND, "iops", "Random IOPS vs queue depth", "K IOPS",
                                  out_dir / "random_iops.png", synthetic, scale=1e-3),
        "Random p99 latency": _line_plot(df, RAND, "lat_p99_us", "Random p99 latency vs queue depth",
                                         "p99 latency (us)", out_dir / "random_p99_latency.png",
                                         synthetic, logy=True),
        "Latency vs throughput": plot_latency_vs_iops(df, out_dir / "latency_vs_iops.png", synthetic),
        "Latency percentiles": plot_percentiles(df, out_dir / "latency_percentiles.png", synthetic),
    }
    return {k: v for k, v in figs.items() if v is not None}


# ---------------------------------------------------------------- findings
def findings(df: pd.DataFrame, links: list[dict]) -> list[str]:
    out: list[str] = []
    for wl, label in [("read", "Sequential read"), ("write", "Sequential write")]:
        g = df[df.workload == wl]
        if not g.empty:
            r = g.loc[g.bandwidth_MBps.idxmax()]
            out.append(f"{label}: peak {r.bandwidth_MBps:,.0f} MB/s ({r.block_size}, QD{int(r.queue_depth)}).")
    for wl, label in [("randread", "Random read"), ("randwrite", "Random write")]:
        g = df[df.workload == wl]
        if g.empty:
            continue
        g = g[g.block_size_kib == g.block_size_kib.min()]
        peak = g.loc[g.iops.idxmax()]
        knee = g[g.iops >= 0.9 * peak.iops].sort_values("queue_depth").iloc[0]
        low = g.sort_values("queue_depth").iloc[0]
        out.append(f"{label} ({peak.block_size}): peak {peak.iops:,.0f} IOPS at QD{int(peak.queue_depth)}; "
                   f"90% of peak is reached by QD{int(knee.queue_depth)} with p99 {knee.lat_p99_us:,.0f} us "
                   f"(p99 at peak: {peak.lat_p99_us:,.0f} us).")
        out.append(f"{label} ({low.block_size}) at QD{int(low.queue_depth)}: "
                   f"p50 {low.lat_p50_us:,.0f} us, p99 {low.lat_p99_us:,.0f} us.")
    for d in links:
        if d.get("downgraded"):
            out.append(f"WARNING: {d.get('model', 'device')} ({d.get('pci_addr', '?')}) runs at "
                       f"{d.get('link_sta_speed')} {d.get('link_sta_width')} but supports "
                       f"{d.get('link_cap_speed')} {d.get('link_cap_width')}; results may be link-limited.")
    return out


# ---------------------------------------------------------------- output
def _b64(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode()


def write_markdown(path, title, synthetic, items, links, meta, figs, df):
    lines = [f"# {title}", ""]
    if synthetic:
        lines += ["> **Synthetic demo data.** Generated by `scripts/make_demo_data.py`; not a real drive.", ""]
    lines += ["## Key findings", "", *[f"- {f}" for f in items], ""]
    if links:
        lines += ["## Device and PCIe link", "", pd.DataFrame(links).to_markdown(index=False), ""]
    if meta:
        lines += ["## Test configuration", "", *[f"- **{k}**: {v}" for k, v in meta.items()], ""]
    lines += ["## Figures", ""]
    lines += [f"![{name}]({p.name})" for name, p in figs.items()]
    show = ["workload", "block_size", "queue_depth", "runs", "bandwidth_MBps", "iops",
            "lat_avg_us", "lat_p50_us", "lat_p99_us", "lat_p999_us"]
    lines += ["", "## Data", "", df[show].round(1).to_markdown(index=False), ""]
    path.write_text("\n".join(lines))


CSS = """
body{font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#1f2937}
h1{margin-bottom:.2rem} h2{margin-top:2rem;border-bottom:1px solid #e5e7eb;padding-bottom:.3rem}
.banner{background:#fef3c7;border:1px solid #f59e0b;padding:.6rem .9rem;border-radius:6px;margin:1rem 0}
.warn{color:#b91c1c;font-weight:600} table{border-collapse:collapse;font-size:13px;margin:.5rem 0}
th,td{border:1px solid #e5e7eb;padding:4px 8px;text-align:right} th{background:#f3f4f6}
td:first-child,th:first-child{text-align:left} img{max-width:100%;margin:.5rem 0}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem} @media(max-width:800px){.grid{grid-template-columns:1fr}}
"""


def write_html(path, title, synthetic, items, links, meta, figs, df):
    e = html.escape
    parts = [f"<!doctype html><html lang='en'><meta charset='utf-8'><title>{e(title)}</title>",
             f"<style>{CSS}</style><body><h1>{e(title)}</h1>"]
    if synthetic:
        parts.append("<div class='banner'><b>Synthetic demo data.</b> Generated by "
                     "<code>scripts/make_demo_data.py</code>; these are not measurements of a real drive.</div>")
    parts.append("<h2>Key findings</h2><ul>")
    parts += [f"<li class='{'warn' if f.startswith('WARNING') else ''}'>{e(f)}</li>" for f in items]
    parts.append("</ul>")
    if links:
        parts += ["<h2>Device and PCIe link</h2>", pd.DataFrame(links).to_html(index=False, border=0)]
    if meta:
        parts.append("<h2>Test configuration</h2><ul>")
        parts += [f"<li><b>{e(str(k))}</b>: {e(str(v))}</li>" for k, v in meta.items()]
        parts.append("</ul>")
    parts.append("<h2>Figures</h2><div class='grid'>")
    parts += [f"<figure style='margin:0'><img alt='{e(n)}' src='data:image/png;base64,{_b64(p)}'></figure>"
              for n, p in figs.items()]
    parts.append("</div><h2>Data</h2>")
    show = ["workload", "block_size", "queue_depth", "runs", "bandwidth_MBps", "iops",
            "lat_avg_us", "lat_p50_us", "lat_p99_us", "lat_p999_us"]
    parts.append(df[show].round(1).to_html(index=False, border=0))
    parts.append("</body></html>")
    path.write_text("\n".join(parts))


def _load_json(path: str | None, default):
    if path and Path(path).is_file():
        try:
            return json.loads(Path(path).read_text())
        except json.JSONDecodeError as exc:
            print(f"warning: could not read {path}: {exc}", file=sys.stderr)
    return default


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("summary", nargs="?", default="results/summary.csv")
    ap.add_argument("out_dir", nargs="?", default="results/report")
    ap.add_argument("--link-info", default="results/link_info.json")
    ap.add_argument("--metadata", default="results/raw/run_metadata.json")
    ap.add_argument("--title", default="NVMe SSD Performance Report")
    args = ap.parse_args(argv)

    if not Path(args.summary).is_file():
        print(f"error: {args.summary} not found (run parse_results.py first)", file=sys.stderr)
        return 2
    df = pd.read_csv(args.summary)
    synthetic = bool(df["synthetic"].any()) if "synthetic" in df else False
    links = _load_json(args.link_info, [])
    meta = _load_json(args.metadata, {})
    meta = {k: v for k, v in meta.items() if k not in ("synthetic", "hostname")}

    out = Path(args.out_dir)
    figs = make_figures(df, out, synthetic)
    items = findings(df, links)
    write_markdown(out / "report.md", args.title, synthetic, items, links, meta, figs, df)
    write_html(out / "report.html", args.title, synthetic, items, links, meta, figs, df)
    print(f"report written to {out} (report.html, report.md, {len(figs)} figures)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
