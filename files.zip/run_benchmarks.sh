#!/usr/bin/env bash
# run_benchmarks.sh - fio sweep for NVMe SSD performance characterization.
#
# Runs sequential and random read/write across block sizes and queue depths and
# saves one fio JSON file per run plus a run_metadata.json describing the setup.
set -Eeuo pipefail

SCRIPT_NAME="$(basename "$0")"

usage() {
  cat << USAGE
Usage: ${SCRIPT_NAME} --target <file|device> [options]

Required:
  -t, --target PATH   Test file (preferred) or block device to benchmark

Options:
  -o, --out DIR       Output directory for raw fio JSON       (default: results/raw)
  -s, --size SIZE     Test file size, fio syntax              (default: 4G)
  -r, --runtime SEC   Measured runtime per run                (default: 30)
      --ramp SEC      Ramp time excluded from statistics      (default: 5)
      --seq-bs SIZE   Sequential block size                   (default: 128k)
      --rand-bs LIST  Random block sizes, space separated     (default: "4k 16k")
      --qd LIST       Queue depths, space separated           (default: "1 4 16 32")
      --repeats N     Repeat every point N times              (default: 1)
      --engine NAME   fio ioengine                            (default: libaio)
      --resume        Skip runs whose output file already exists
      --keep-file     Keep a test file this script created
      --dry-run       Print the fio commands without running them
      --i-understand-data-loss
                      Required when the target is a raw block device
  -h, --help          Show this help

Example:
  ${SCRIPT_NAME} -t /mnt/nvme/fio_testfile -s 8G -r 60 --qd "1 8 32" --repeats 3
USAGE
}

# ---------- logging ----------
if [[ -t 2 ]]; then C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YLW=$'\033[33m'; C_OFF=$'\033[0m'
else C_RED=""; C_GRN=""; C_YLW=""; C_OFF=""; fi
info() { printf '%s[info]%s %s\n' "$C_GRN" "$C_OFF" "$*" >&2; }
warn() { printf '%s[warn]%s %s\n' "$C_YLW" "$C_OFF" "$*" >&2; }
die()  { printf '%s[error]%s %s\n' "$C_RED" "$C_OFF" "$*" >&2; exit 1; }

# ---------- defaults ----------
TARGET=""; OUTDIR="results/raw"; SIZE="4G"; RUNTIME=30; RAMP=5
SEQ_BS="128k"; RAND_BS="4k 16k"; QDS="1 4 16 32"; REPEATS=1; ENGINE="libaio"
RESUME=0; KEEP_FILE=0; DRY_RUN=0; ACK_DATA_LOSS=0
CREATED_FILE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--target)  TARGET="${2:?missing value for $1}"; shift 2 ;;
    -o|--out)     OUTDIR="${2:?missing value for $1}"; shift 2 ;;
    -s|--size)    SIZE="${2:?missing value for $1}"; shift 2 ;;
    -r|--runtime) RUNTIME="${2:?missing value for $1}"; shift 2 ;;
    --ramp)       RAMP="${2:?missing value for $1}"; shift 2 ;;
    --seq-bs)     SEQ_BS="${2:?missing value for $1}"; shift 2 ;;
    --rand-bs)    RAND_BS="${2:?missing value for $1}"; shift 2 ;;
    --qd)         QDS="${2:?missing value for $1}"; shift 2 ;;
    --repeats)    REPEATS="${2:?missing value for $1}"; shift 2 ;;
    --engine)     ENGINE="${2:?missing value for $1}"; shift 2 ;;
    --resume)     RESUME=1; shift ;;
    --keep-file)  KEEP_FILE=1; shift ;;
    --dry-run)    DRY_RUN=1; shift ;;
    --i-understand-data-loss) ACK_DATA_LOSS=1; shift ;;
    -h|--help)    usage; exit 0 ;;
    *) usage >&2; die "unknown option: $1" ;;
  esac
done

[[ -n "$TARGET" ]] || { usage >&2; die "--target is required"; }
[[ "$RUNTIME" =~ ^[0-9]+$ && "$RUNTIME" -gt 0 ]] || die "--runtime must be a positive integer"
[[ "$RAMP" =~ ^[0-9]+$ ]] || die "--ramp must be a non-negative integer"
[[ "$REPEATS" =~ ^[0-9]+$ && "$REPEATS" -gt 0 ]] || die "--repeats must be a positive integer"
for q in $QDS; do [[ "$q" =~ ^[0-9]+$ && "$q" -gt 0 ]] || die "invalid queue depth: $q"; done

# fio-style size (4G, 512M, ...) -> KiB
size_to_kib() {
  local s="${1^^}" n unit
  [[ "$s" =~ ^([0-9]+)([KMGT]?)I?B?$ ]] || die "cannot parse size: $1"
  n="${BASH_REMATCH[1]}"; unit="${BASH_REMATCH[2]}"
  case "$unit" in
    ""|K) echo "$n" ;;
    M) echo $(( n * 1024 )) ;;
    G) echo $(( n * 1024 * 1024 )) ;;
    T) echo $(( n * 1024 * 1024 * 1024 )) ;;
  esac
}

json_escape() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

cleanup() {
  if [[ "$CREATED_FILE" -eq 1 && "$KEEP_FILE" -eq 0 && -f "$TARGET" ]]; then
    info "removing test file $TARGET"
    rm -f -- "$TARGET"
  fi
}
trap cleanup EXIT
trap 'warn "interrupted"; exit 130' INT TERM

# ---------- preflight ----------
FIO_VERSION="unknown"
if [[ "$DRY_RUN" -eq 0 ]]; then
  command -v fio > /dev/null || die "fio not found (try: sudo apt install fio)"
  FIO_VERSION="$(fio --version 2> /dev/null || echo unknown)"
fi

TARGET_TYPE="file"
if [[ -b "$TARGET" ]]; then
  TARGET_TYPE="block_device"
  [[ "$ACK_DATA_LOSS" -eq 1 ]] || die "$TARGET is a block device; benchmarking it can destroy data. Re-run with --i-understand-data-loss, or use a test file."
  if command -v lsblk > /dev/null && lsblk -nro MOUNTPOINT "$TARGET" 2> /dev/null | grep -q .; then
    die "$TARGET (or a partition on it) is mounted; refusing to continue"
  fi
else
  dir="$(dirname "$TARGET")"
  [[ -d "$dir" && -w "$dir" ]] || die "directory not writable: $dir"
  need_kib="$(size_to_kib "$SIZE")"
  avail_kib="$(df -Pk "$dir" | awk 'NR==2 {print $4}')"
  if (( avail_kib < need_kib + need_kib / 20 )); then
    die "not enough free space in $dir (need ~${SIZE}, have $(( avail_kib / 1024 )) MiB)"
  fi
  if [[ ! -e "$TARGET" && "$DRY_RUN" -eq 0 ]]; then CREATED_FILE=1; fi
fi

# ---------- plan ----------
declare -a PLAN=()
for qd in $QDS; do
  for rw in read write; do PLAN+=("$rw $SEQ_BS $qd"); done
  for bs in $RAND_BS; do
    for rw in randread randwrite; do PLAN+=("$rw $bs $qd"); done
  done
done
TOTAL=$(( ${#PLAN[@]} * REPEATS ))
EST_MIN=$(( TOTAL * (RUNTIME + RAMP) / 60 ))
info "target=$TARGET ($TARGET_TYPE) size=$SIZE runs=$TOTAL est=${EST_MIN} min"

mkdir -p "$OUTDIR"

if [[ "$DRY_RUN" -eq 0 ]]; then
  cat > "$OUTDIR/run_metadata.json" << META
{
  "timestamp_utc": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "hostname": "$(json_escape "$(hostname)")",
  "kernel": "$(json_escape "$(uname -r)")",
  "fio_version": "$(json_escape "$FIO_VERSION")",
  "target": "$(json_escape "$TARGET")",
  "target_type": "$TARGET_TYPE",
  "size": "$SIZE",
  "runtime_s": $RUNTIME,
  "ramp_s": $RAMP,
  "seq_bs": "$SEQ_BS",
  "rand_bs": "$(json_escape "$RAND_BS")",
  "queue_depths": "$(json_escape "$QDS")",
  "repeats": $REPEATS,
  "ioengine": "$ENGINE"
}
META
fi

# ---------- run ----------
run_one() {  # rw bs qd rep
  local rw="$1" bs="$2" qd="$3" rep="$4"
  local out="$OUTDIR/${rw}_bs${bs}_qd${qd}_run${rep}.json"
  local -a cmd=(fio --name="${rw}_${bs}_qd${qd}" --filename="$TARGET" --size="$SIZE"
    --rw="$rw" --bs="$bs" --iodepth="$qd" --numjobs=1 --ioengine="$ENGINE"
    --direct=1 --time_based --runtime="$RUNTIME" --ramp_time="$RAMP"
    --randrepeat=0 --refill_buffers --group_reporting
    --percentile_list=50:90:99:99.9:99.99
    --output-format=json --output="$out")
  if [[ "$DRY_RUN" -eq 1 ]]; then printf '%q ' "${cmd[@]}"; echo; return 0; fi
  if [[ "$RESUME" -eq 1 && -s "$out" ]]; then info "skip (exists): $out"; return 0; fi
  "${cmd[@]}"
}

done_n=0; failed=0
for rep in $(seq 1 "$REPEATS"); do
  for point in "${PLAN[@]}"; do
    read -r rw bs qd <<< "$point"
    done_n=$(( done_n + 1 ))
    info "[$done_n/$TOTAL] rw=$rw bs=$bs qd=$qd run=$rep"
    run_one "$rw" "$bs" "$qd" "$rep" || { warn "run failed: $point"; failed=$(( failed + 1 )); }
  done
done

if [[ "$failed" -gt 0 ]]; then die "$failed of $TOTAL runs failed"; fi
info "done. Next: python scripts/parse_results.py $OUTDIR results/summary.csv"
