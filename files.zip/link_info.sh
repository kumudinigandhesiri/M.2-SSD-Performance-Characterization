#!/usr/bin/env bash
# link_info.sh - record NVMe devices and their negotiated PCIe link.
#
# Writes results/link_info.txt (human readable) and results/link_info.json
# (consumed by report.py). Flags devices whose link speed or width is below
# what the device supports ("downgraded"), a common cause of low performance.
# Run as root for full lspci capability output and nvme smart-log.
set -uo pipefail

OUT_DIR="${1:-results}"
mkdir -p "$OUT_DIR"
TXT="$OUT_DIR/link_info.txt"
JSON="$OUT_DIR/link_info.json"

command -v lspci > /dev/null || { echo "lspci not found (sudo apt install pciutils)" >&2; exit 1; }
[[ $EUID -eq 0 ]] || echo "note: not running as root; some PCIe fields may be hidden" >&2

json_escape() { printf '%s' "$1" | tr -d '\n' | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }
first_speed() { grep -oE 'Speed [0-9.]+GT/s' <<< "$1" | head -n1 | awk '{print $2}'; }
first_width() { grep -oE 'Width x[0-9]+' <<< "$1" | head -n1 | awk '{print $2}'; }
num() { grep -oE '[0-9]+(\.[0-9]+)?' <<< "$1" | head -n1; }

mapfile -t DEVS < <(lspci -D -nn | awk '/\[0108\]/ {print $1}')
if [[ ${#DEVS[@]} -eq 0 ]]; then echo "no NVMe PCIe devices found" >&2; echo "[]" > "$JSON"; exit 0; fi

ENTRIES=()
{
  echo "=== link_info ($(date -u +%Y-%m-%dT%H:%M:%SZ)) ==="
  printf '%-14s %-34s %-16s %-16s %s\n' "PCI address" "Model" "Capable" "Negotiated" "Status"
  for dev in "${DEVS[@]}"; do
    vv="$(lspci -vv -s "$dev" 2> /dev/null)"
    cap_line="$(grep -m1 'LnkCap:' <<< "$vv")"
    sta_line="$(grep -m1 'LnkSta:' <<< "$vv")"
    cap_speed="$(first_speed "$cap_line")"; cap_width="$(first_width "$cap_line")"
    sta_speed="$(first_speed "$sta_line")"; sta_width="$(first_width "$sta_line")"

    model="unknown"
    for f in /sys/bus/pci/devices/"$dev"/nvme/nvme*/model; do
      [[ -r "$f" ]] && model="$(tr -s ' ' < "$f" | sed 's/[[:space:]]*$//')" && break
    done
    ctrl="$(basename "$(dirname "$(ls /sys/bus/pci/devices/"$dev"/nvme/nvme*/model 2> /dev/null | head -n1)")" 2> /dev/null)"
    temp="null"
    if [[ $EUID -eq 0 && -n "$ctrl" ]] && command -v nvme > /dev/null; then
      t="$(nvme smart-log "/dev/$ctrl" 2> /dev/null | awk -F: '/^temperature/ {gsub(/[^0-9]/,"",$2); print $2; exit}')"
      [[ -n "$t" ]] && temp="$t"
    fi

    downgraded=false; status="ok"
    if [[ -n "$cap_speed$sta_speed$cap_width$sta_width" ]]; then
      if awk -v a="$(num "$sta_speed")" -v b="$(num "$cap_speed")" -v c="$(num "$sta_width")" -v d="$(num "$cap_width")" \
          'BEGIN { exit !((a != "" && b != "" && a < b) || (c != "" && d != "" && c < d)) }'; then
        downgraded=true; status="DOWNGRADED"
      fi
    else
      status="link data unavailable"
    fi

    printf '%-14s %-34s %-16s %-16s %s\n' "$dev" "${model:0:34}" "${cap_speed:-?} ${cap_width:-?}" "${sta_speed:-?} ${sta_width:-?}" "$status"
    ENTRIES+=("  {\"pci_addr\": \"$(json_escape "$dev")\", \"model\": \"$(json_escape "$model")\", \"link_cap_speed\": \"${cap_speed}\", \"link_cap_width\": \"${cap_width}\", \"link_sta_speed\": \"${sta_speed}\", \"link_sta_width\": \"${sta_width}\", \"downgraded\": ${downgraded}, \"temperature_c\": ${temp}}")
  done
  echo
  echo "=== lspci -vv (link lines) ==="
  for dev in "${DEVS[@]}"; do echo "--- $dev ---"; lspci -vv -s "$dev" 2> /dev/null | grep -E 'LnkCap:|LnkSta:' || true; done
  echo
  echo "=== kernel log (nvme / pcie / aer, last 100) ==="
  dmesg 2> /dev/null | grep -iE 'nvme|pcie|aer' | tail -n 100 || echo "(dmesg not readable)"
} > "$TXT"   # no pipe here: ENTRIES must stay in this shell
cat "$TXT"

{ echo "["; (IFS=$',\n'; echo "${ENTRIES[*]}"); echo "]"; } > "$JSON"
echo "wrote $TXT and $JSON" >&2
