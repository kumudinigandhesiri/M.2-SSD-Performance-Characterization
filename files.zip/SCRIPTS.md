# Script guide: M.2 NVMe SSD Performance Characterization Toolkit

This guide documents every script in the toolkit: what it does, how it works, the design
decisions behind it, how it fails, and the full source. Read the overview first, then jump
to the script you need.

## Overview

| # | Script | Language | Role | Reads | Writes |
|---|---|---|---|---|---|
| 1 | `scripts/link_info.sh` | Bash | Record device and PCIe link state | `lspci`, sysfs, `nvme`, `dmesg` | `link_info.txt`, `link_info.json` |
| 2 | `scripts/run_benchmarks.sh` | Bash | Run the fio sweep | fio | `raw/*.json`, `run_metadata.json` |
| 3 | `scripts/parse_results.py` | Python | Turn raw fio JSON into one CSV | `raw/*.json` | `summary.csv` |
| 4 | `scripts/report.py` | Python | Build plots, findings, HTML and Markdown report | `summary.csv`, `link_info.json`, `run_metadata.json` | `report/` |
| 5 | `scripts/make_demo_data.py` | Python | Generate SYNTHETIC fio-format data for demos and tests | none | `demo/raw/`, `demo/link_info.json` |

Data flow:

```
link_info.sh -----------------------------+
                                           v
run_benchmarks.sh --> raw/*.json --> parse_results.py --> summary.csv --> report.py --> report.html / report.md / PNGs
make_demo_data.py --> (same raw format, marked synthetic) --^
```

Order for a real run: `link_info.sh`, then `run_benchmarks.sh`, then `parse_results.py`, then `report.py`.
Recording the link first lets the report show whether a result is link-limited.

Conventions shared by all scripts:
- **Units:** bandwidth in decimal MB/s (fio reports KiB/s and the parser converts), latency in microseconds.
- **File naming:** raw results are `<workload>_bs<size>_qd<N>_run<K>.json`, for example `randread_bs4k_qd16_run2.json`. The parser reads the test point from the file name, so do not rename these files.
- **Synthetic data:** demo files carry `"synthetic": true`. The parser keeps that flag and the report adds a banner and a watermark, so demo output cannot be mistaken for real measurements.

---

## 1. `scripts/link_info.sh`: record the device and PCIe link

**Purpose.** Find every NVMe controller on the PCIe bus and record the link it supports versus the
link it actually negotiated. A drive that supports Gen4 x4 but runs at Gen3 or x2 looks "slow" for
reasons unrelated to the drive itself, so this check comes first.

**Usage**
```bash
sudo ./scripts/link_info.sh            # writes to results/
sudo ./scripts/link_info.sh my_output  # writes to my_output/
```

**Requirements:** `lspci` (package `pciutils`). Optional: `nvme-cli` for drive temperature. Run as root for full output.

**How it works**
1. Lists PCI devices with `lspci -D -nn` and keeps those whose class code is `[0108]` (NVMe storage controller).
2. For each device, runs `lspci -vv -s <address>` and extracts the `LnkCap` line (what the device supports) and the `LnkSta` line (what it negotiated). Speed (for example `16GT/s`) and width (for example `x4`) are parsed from each.
3. Reads the drive model from sysfs (`/sys/bus/pci/devices/<addr>/nvme/nvme*/model`).
4. As root, with `nvme-cli` present, reads the composite temperature from `nvme smart-log`.
5. Compares negotiated speed and width with the supported values using `awk`; if either is lower, marks the device `DOWNGRADED`.
6. Writes a human-readable report (device table, link lines and the last 100 NVMe/PCIe/AER kernel log lines) and a JSON list that `report.py` reads.

**Output files**
- `link_info.txt`: for people. Includes the kernel log excerpt, useful for spotting PCIe errors or retrains.
- `link_info.json`: for `report.py`. Fields: `pci_addr`, `model`, `link_cap_speed`, `link_cap_width`, `link_sta_speed`, `link_sta_width`, `downgraded`, `temperature_c`.

**Design decisions**
- The report text is written to a file and then printed, not piped through `tee`. A pipe would run the loop in a subshell and lose the array used to build the JSON (this was an actual bug found in testing).
- Missing fields do not abort the script. If `lspci` hides capability fields without root, the status reads "link data unavailable" instead of guessing.
- JSON is assembled by hand with escaping for quotes and backslashes, so the script needs no `jq`.

**Limitations and failure modes**
- Without root, some `lspci` fields may be hidden. The script prints a note.
- A link can legitimately train down to save power when the drive is idle. Check the link under load before treating a downgrade as a fault.
- The script exits with an error if `lspci` is missing, and writes an empty list if no NVMe device is found.
- Tested here only with a stand-in `lspci`; run it on real hardware and compare against `lspci -vv` yourself.

**Source**

```bash
#!/usr/bin/env bash
# link_info.sh - record NVMe devices and their negotiated PCIe link.
#
# Writes results/link_info.txt (human readable) and results/link_info.json
# (consumed by report.py). Flags devices whose link speed or width is below
# what the device supports ("downgraded"), a common cause of low performance.
# Run as root for full lspci capability output and nvme smart-log.
set -uo pipefail

OUT_DIR="${1:-results}"
mkdir -p "$OUT_DIR"
TXT="$OUT_DIR/link_info.txt"
JSON="$OUT_DIR/link_info.json"

command -v lspci > /dev/null || { echo "lspci not found (sudo apt install pciutils)" >&2; exit 1; }
[[ $EUID -eq 0 ]] || echo "note: not running as root; some PCIe fields may be hidden" >&2

json_escape() { printf '%s' "$1" | tr -d '\n' | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }
first_speed() { grep -oE 'Speed [0-9.]+GT/s' <<< "$1" | head -n1 | awk '{print $2}'; }
first_width() { grep -oE 'Width x[0-9]+' <<< "$1" | head -n1 | awk '{print $2}'; }
num() { grep -oE '[0-9]+(\.[0-9]+)?' <<< "$1" | head -n1; }

mapfile -t DEVS < <(lspci -D -nn | awk '/\[0108\]/ {print $1}')
if [[ ${#DEVS[@]} -eq 0 ]]; then echo "no NVMe PCIe devices found" >&2; echo "[]" > "$JSON"; exit 0; fi

ENTRIES=()
{
  echo "=== link_info ($(date -u +%Y-%m-%dT%H:%M:%SZ)) ==="
  printf '%-14s %-34s %-16s %-16s %s\n' "PCI address" "Model" "Capable" "Negotiated" "Status"
  for dev in "${DEVS[@]}"; do
    vv="$(lspci -vv -s "$dev" 2> /dev/null)"
    cap_line="$(grep -m1 'LnkCap:' <<< "$vv")"
    sta_line="$(grep -m1 'LnkSta:' <<< "$vv")"
    cap_speed="$(first_speed "$cap_line")"; cap_width="$(first_width "$cap_line")"
    sta_speed="$(first_speed "$sta_line")"; sta_width="$(first_width "$sta_line")"

    model="unknown"
    for f in /sys/bus/pci/devices/"$dev"/nvme/nvme*/model; do
      [[ -r "$f" ]] && model="$(tr -s ' ' < "$f" | sed 's/[[:space:]]*$//')" && break
    done
    ctrl="$(basename "$(dirname "$(ls /sys/bus/pci/devices/"$dev"/nvme/nvme*/model 2> /dev/null | head -n1)")" 2> /dev/null)"
    temp="null"
    if [[ $EUID -eq 0 && -n "$ctrl" ]] && command -v nvme > /dev/null; then
      t="$(nvme smart-log "/dev/$ctrl" 2> /dev/null | awk -F: '/^temperature/ {gsub(/[^0-9]/,"",$2); print $2; exit}')"
      [[ -n "$t" ]] && temp="$t"
    fi

    downgraded=false; status="ok"
    if [[ -n "$cap_speed$sta_speed$cap_width$sta_width" ]]; then
      if awk -v a="$(num "$sta_speed")" -v b="$(num "$cap_speed")" -v c="$(num "$sta_width")" -v d="$(num "$cap_width")" \
          'BEGIN { exit !((a != "" && b != "" && a < b) || (c != "" && d != "" && c < d)) }'; then
        downgraded=true; status="DOWNGRADED"
      fi
    else
      status="link data unavailable"
    fi

    printf '%-14s %-34s %-16s %-16s %s\n' "$dev" "${model:0:34}" "${cap_speed:-?} ${cap_width:-?}" "${sta_speed:-?} ${sta_width:-?}" "$status"
    ENTRIES+=("  {\"pci_addr\": \"$(json_escape "$dev")\", \"model\": \"$(json_escape "$model")\", \"link_cap_speed\": \"${cap_speed}\", \"link_cap_width\": \"${cap_width}\", \"link_sta_speed\": \"${sta_speed}\", \"link_sta_width\": \"${sta_width}\", \"downgraded\": ${downgraded}, \"temperature_c\": ${temp}}")
  done
  echo
  echo "=== lspci -vv (link lines) ==="
  for dev in "${DEVS[@]}"; do echo "--- $dev ---"; lspci -vv -s "$dev" 2> /dev/null | grep -E 'LnkCap:|LnkSta:' || true; done
  echo
  echo "=== kernel log (nvme / pcie / aer, last 100) ==="
  dmesg 2> /dev/null | grep -iE 'nvme|pcie|aer' | tail -n 100 || echo "(dmesg not readable)"
} > "$TXT"   # no pipe here: ENTRIES must stay in this shell
cat "$TXT"

{ echo "["; (IFS=$',\n'; echo "${ENTRIES[*]}"); echo "]"; } > "$JSON"
echo "wrote $TXT and $JSON" >&2
```

---

## 2. `scripts/run_benchmarks.sh`: run the fio sweep

**Purpose.** Run a repeatable set of sequential and random read/write tests across queue depths (and
block sizes for random I/O), saving one fio JSON file per run plus a record of the test setup.

**Usage**
```bash
./scripts/run_benchmarks.sh -t /mnt/nvme/fio_testfile --dry-run          # preview commands
./scripts/run_benchmarks.sh -t /mnt/nvme/fio_testfile                    # defaults
./scripts/run_benchmarks.sh -t /mnt/nvme/fio_testfile -s 8G -r 60 --qd "1 8 32" --repeats 3
./scripts/run_benchmarks.sh -t /mnt/nvme/fio_testfile --resume           # continue an interrupted sweep
```

**Options**

| Option | Default | Meaning |
|---|---|---|
| `-t, --target` | required | Test file (preferred) or block device |
| `-o, --out` | `results/raw` | Output directory |
| `-s, --size` | `4G` | Test file size |
| `-r, --runtime` | `30` | Measured seconds per run |
| `--ramp` | `5` | Seconds excluded from statistics |
| `--seq-bs` | `128k` | Sequential block size |
| `--rand-bs` | `"4k 16k"` | Random block sizes |
| `--qd` | `"1 4 16 32"` | Queue depths |
| `--repeats` | `1` | Repeats of every point |
| `--engine` | `libaio` | fio I/O engine |
| `--resume` | off | Skip runs whose output exists |
| `--keep-file` | off | Keep a test file the script created |
| `--dry-run` | off | Print fio commands only |
| `--i-understand-data-loss` | off | Required for raw block devices |

**How it works**
1. Parses options and validates numbers (runtime, ramp, repeats, queue depths).
2. **Preflight:** checks that fio exists and records its version. For a block device it requires the data-loss flag and refuses mounted devices. For a file it checks the directory is writable and that free space covers the file size plus 5%.
3. Builds a plan: for each queue depth, sequential read and write at the sequential block size, then random read and write at each random block size.
4. Prints the number of runs and an estimated time, then writes `run_metadata.json` (timestamp, host, kernel, fio version, every parameter).
5. Runs each point through fio with direct I/O, a ramp period, `--randrepeat=0` so random patterns differ between runs, `--refill_buffers` so data is not compressible or deduplicated, and the percentile list `50:90:99:99.9:99.99`.
6. Logs progress as `[n/total]`, counts failed runs, and exits non-zero if any run failed.
7. On exit, deletes the test file only if this script created it (unless `--keep-file`).

**Design decisions**
- **Safety first.** Benchmarking a raw device overwrites data, so it needs an explicit long flag, and mounted devices are refused outright.
- **Direct I/O** (`--direct=1`) so results reflect the drive, not the page cache.
- **Ramp time** keeps startup effects out of the numbers.
- **Resume support** matters because a sweep with repeats can take hours.
- **Dry run** lets you review exactly what will execute.
- The file name carries workload, block size, queue depth and run number; the parser depends on this.

**Estimated runtime.** Runs = (2 sequential + 2 x number of random block sizes) x number of queue depths x repeats. Time is roughly runs x (runtime + ramp). The defaults give 24 runs, about 14 minutes. Three repeats at 60 seconds give about 3 hours.

**Limitations and failure modes**
- Single job per run. Mixed read/write ratios and multi-job scaling are not covered.
- Short write runs may not exhaust the drive's SLC cache, so write numbers can look better than sustained performance.
- The script cannot detect thermal throttling by itself; check temperature with `nvme smart-log` during long runs.
- The block-device branch could only be reviewed, not run, in the development environment. Test it on a scratch drive.
- Linux only; the `libaio` engine must be available to fio.

**Source**

```bash
#!/usr/bin/env bash
# run_benchmarks.sh - fio sweep for NVMe SSD performance characterization.
#
# Runs sequential and random read/write across block sizes and queue depths and
# saves one fio JSON file per run plus a run_metadata.json describing the setup.
set -Eeuo pipefail

SCRIPT_NAME="$(basename "$0")"

usage() {
  cat << USAGE
Usage: ${SCRIPT_NAME} --target <file|device> [options]

Required:
  -t, --target PATH   Test file (preferred) or block device to benchmark

Options:
  -o, --out DIR       Output directory for raw fio JSON       (default: results/raw)
  -s, --size SIZE     Test file size, fio syntax              (default: 4G)
  -r, --runtime SEC   Measured runtime per run                (default: 30)
      --ramp SEC      Ramp time excluded from statistics      (default: 5)
      --seq-bs SIZE   Sequential block size                   (default: 128k)
      --rand-bs LIST  Random block sizes, space separated     (default: "4k 16k")
      --qd LIST       Queue depths, space separated           (default: "1 4 16 32")
      --repeats N     Repeat every point N times              (default: 1)
      --engine NAME   fio ioengine                            (default: libaio)
      --resume        Skip runs whose output file already exists
      --keep-file     Keep a test file this script created
      --dry-run       Print the fio commands without running them
      --i-understand-data-loss
                      Required when the target is a raw block device
  -h, --help          Show this help

Example:
  ${SCRIPT_NAME} -t /mnt/nvme/fio_testfile -s 8G -r 60 --qd "1 8 32" --repeats 3
USAGE
}

# ---------- logging ----------
if [[ -t 2 ]]; then C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YLW=$'\033[33m'; C_OFF=$'\033[0m'
else C_RED=""; C_GRN=""; C_YLW=""; C_OFF=""; fi
info() { printf '%s[info]%s %s\n' "$C_GRN" "$C_OFF" "$*" >&2; }
warn() { printf '%s[warn]%s %s\n' "$C_YLW" "$C_OFF" "$*" >&2; }
die()  { printf '%s[error]%s %s\n' "$C_RED" "$C_OFF" "$*" >&2; exit 1; }

# ---------- defaults ----------
TARGET=""; OUTDIR="results/raw"; SIZE="4G"; RUNTIME=30; RAMP=5
SEQ_BS="128k"; RAND_BS="4k 16k"; QDS="1 4 16 32"; REPEATS=1; ENGINE="libaio"
RESUME=0; KEEP_FILE=0; DRY_RUN=0; ACK_DATA_LOSS=0
CREATED_FILE=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    -t|--target)  TARGET="${2:?missing value for $1}"; shift 2 ;;
    -o|--out)     OUTDIR="${2:?missing value for $1}"; shift 2 ;;
    -s|--size)    SIZE="${2:?missing value for $1}"; shift 2 ;;
    -r|--runtime) RUNTIME="${2:?missing value for $1}"; shift 2 ;;
    --ramp)       RAMP="${2:?missing value for $1}"; shift 2 ;;
    --seq-bs)     SEQ_BS="${2:?missing value for $1}"; shift 2 ;;
    --rand-bs)    RAND_BS="${2:?missing value for $1}"; shift 2 ;;
    --qd)         QDS="${2:?missing value for $1}"; shift 2 ;;
    --repeats)    REPEATS="${2:?missing value for $1}"; shift 2 ;;
    --engine)     ENGINE="${2:?missing value for $1}"; shift 2 ;;
    --resume)     RESUME=1; shift ;;
    --keep-file)  KEEP_FILE=1; shift ;;
    --dry-run)    DRY_RUN=1; shift ;;
    --i-understand-data-loss) ACK_DATA_LOSS=1; shift ;;
    -h|--help)    usage; exit 0 ;;
    *) usage >&2; die "unknown option: $1" ;;
  esac
done

[[ -n "$TARGET" ]] || { usage >&2; die "--target is required"; }
[[ "$RUNTIME" =~ ^[0-9]+$ && "$RUNTIME" -gt 0 ]] || die "--runtime must be a positive integer"
[[ "$RAMP" =~ ^[0-9]+$ ]] || die "--ramp must be a non-negative integer"
[[ "$REPEATS" =~ ^[0-9]+$ && "$REPEATS" -gt 0 ]] || die "--repeats must be a positive integer"
for q in $QDS; do [[ "$q" =~ ^[0-9]+$ && "$q" -gt 0 ]] || die "invalid queue depth: $q"; done

# fio-style size (4G, 512M, ...) -> KiB
size_to_kib() {
  local s="${1^^}" n unit
  [[ "$s" =~ ^([0-9]+)([KMGT]?)I?B?$ ]] || die "cannot parse size: $1"
  n="${BASH_REMATCH[1]}"; unit="${BASH_REMATCH[2]}"
  case "$unit" in
    ""|K) echo "$n" ;;
    M) echo $(( n * 1024 )) ;;
    G) echo $(( n * 1024 * 1024 )) ;;
    T) echo $(( n * 1024 * 1024 * 1024 )) ;;
  esac
}

json_escape() { printf '%s' "$1" | sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }

cleanup() {
  if [[ "$CREATED_FILE" -eq 1 && "$KEEP_FILE" -eq 0 && -f "$TARGET" ]]; then
    info "removing test file $TARGET"
    rm -f -- "$TARGET"
  fi
}
trap cleanup EXIT
trap 'warn "interrupted"; exit 130' INT TERM

# ---------- preflight ----------
FIO_VERSION="unknown"
if [[ "$DRY_RUN" -eq 0 ]]; then
  command -v fio > /dev/null || die "fio not found (try: sudo apt install fio)"
  FIO_VERSION="$(fio --version 2> /dev/null || echo unknown)"
fi

TARGET_TYPE="file"
if [[ -b "$TARGET" ]]; then
  TARGET_TYPE="block_device"
  [[ "$ACK_DATA_LOSS" -eq 1 ]] || die "$TARGET is a block device; benchmarking it can destroy data. Re-run with --i-understand-data-loss, or use a test file."
  if command -v lsblk > /dev/null && lsblk -nro MOUNTPOINT "$TARGET" 2> /dev/null | grep -q .; then
    die "$TARGET (or a partition on it) is mounted; refusing to continue"
  fi
else
  dir="$(dirname "$TARGET")"
  [[ -d "$dir" && -w "$dir" ]] || die "directory not writable: $dir"
  need_kib="$(size_to_kib "$SIZE")"
  avail_kib="$(df -Pk "$dir" | awk 'NR==2 {print $4}')"
  if (( avail_kib < need_kib + need_kib / 20 )); then
    die "not enough free space in $dir (need ~${SIZE}, have $(( avail_kib / 1024 )) MiB)"
  fi
  if [[ ! -e "$TARGET" && "$DRY_RUN" -eq 0 ]]; then CREATED_FILE=1; fi
fi

# ---------- plan ----------
declare -a PLAN=()
for qd in $QDS; do
  for rw in read write; do PLAN+=("$rw $SEQ_BS $qd"); done
  for bs in $RAND_BS; do
    for rw in randread randwrite; do PLAN+=("$rw $bs $qd"); done
  done
done
TOTAL=$(( ${#PLAN[@]} * REPEATS ))
EST_MIN=$(( TOTAL * (RUNTIME + RAMP) / 60 ))
info "target=$TARGET ($TARGET_TYPE) size=$SIZE runs=$TOTAL est=${EST_MIN} min"

mkdir -p "$OUTDIR"

if [[ "$DRY_RUN" -eq 0 ]]; then
  cat > "$OUTDIR/run_metadata.json" << META
{
  "timestamp_utc": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "hostname": "$(json_escape "$(hostname)")",
  "kernel": "$(json_escape "$(uname -r)")",
  "fio_version": "$(json_escape "$FIO_VERSION")",
  "target": "$(json_escape "$TARGET")",
  "target_type": "$TARGET_TYPE",
  "size": "$SIZE",
  "runtime_s": $RUNTIME,
  "ramp_s": $RAMP,
  "seq_bs": "$SEQ_BS",
  "rand_bs": "$(json_escape "$RAND_BS")",
  "queue_depths": "$(json_escape "$QDS")",
  "repeats": $REPEATS,
  "ioengine": "$ENGINE"
}
META
fi

# ---------- run ----------
run_one() {  # rw bs qd rep
  local rw="$1" bs="$2" qd="$3" rep="$4"
  local out="$OUTDIR/${rw}_bs${bs}_qd${qd}_run${rep}.json"
  local -a cmd=(fio --name="${rw}_${bs}_qd${qd}" --filename="$TARGET" --size="$SIZE"
    --rw="$rw" --bs="$bs" --iodepth="$qd" --numjobs=1 --ioengine="$ENGINE"
    --direct=1 --time_based --runtime="$RUNTIME" --ramp_time="$RAMP"
    --randrepeat=0 --refill_buffers --group_reporting
    --percentile_list=50:90:99:99.9:99.99
    --output-format=json --output="$out")
  if [[ "$DRY_RUN" -eq 1 ]]; then printf '%q ' "${cmd[@]}"; echo; return 0; fi
  if [[ "$RESUME" -eq 1 && -s "$out" ]]; then info "skip (exists): $out"; return 0; fi
  "${cmd[@]}"
}

done_n=0; failed=0
for rep in $(seq 1 "$REPEATS"); do
  for point in "${PLAN[@]}"; do
    read -r rw bs qd <<< "$point"
    done_n=$(( done_n + 1 ))
    info "[$done_n/$TOTAL] rw=$rw bs=$bs qd=$qd run=$rep"
    run_one "$rw" "$bs" "$qd" "$rep" || { warn "run failed: $point"; failed=$(( failed + 1 )); }
  done
done

if [[ "$failed" -gt 0 ]]; then die "$failed of $TOTAL runs failed"; fi
info "done. Next: python scripts/parse_results.py $OUTDIR results/summary.csv"
```

---

## 3. `scripts/parse_results.py`: raw fio JSON to one CSV

**Purpose.** Convert the per-run JSON files into a single tidy table, averaging repeated runs and
converting units, so the report (or a spreadsheet) can use it directly.

**Usage**
```bash
python scripts/parse_results.py results/raw results/summary.csv
```

**How it works**
1. Finds `*.json` files in the directory and ignores `run_metadata.json`.
2. Parses the test point (workload, block size, queue depth, run) from the file name with a regular expression. Files with other names are skipped.
3. Loads the JSON, tolerating warning text that fio sometimes prints before the JSON object.
4. Picks the right side of the result: the `write` section for write workloads, otherwise `read`. Rejects jobs where fio reported an error.
5. Extracts bandwidth, IOPS, mean completion latency and the percentiles (p50, p90, p99, p99.9, p99.99). It supports both `clat_ns` (nanoseconds, fio 3.x) and the older `clat` (microseconds).
6. Converts units: bandwidth from KiB/s to decimal MB/s, latency to microseconds.
7. Groups by workload, block size and queue depth; averages the metrics across repeats; adds `runs` (count) and `iops_std` (spread).
8. Writes the CSV. Prints a warning for each skipped file and returns a non-zero exit code if nothing was usable.

**Output columns:** `workload`, `block_size`, `block_size_kib`, `queue_depth`, `runs`, `bandwidth_MBps`, `iops`, `lat_avg_us`, `lat_p50_us`, `lat_p90_us`, `lat_p99_us`, `lat_p999_us`, `lat_p9999_us`, `iops_std`, `synthetic`.

**Design decisions**
- **One bad file never ruins the run.** Problems are collected, reported and skipped.
- **Units are explicit and tested.** An earlier draft divided KiB/s by 1024 and labelled it MB/s; the parser now converts to decimal MB/s, which matches how SSD vendors quote speed. A unit test pins this.
- **Percentiles stay NaN, not zero, when fio did not report them.** Averages would otherwise be wrong.
- The `synthetic` flag survives aggregation so downstream tools can warn.

**Limitations**
- Only the first job in each file is read (the sweep uses one job).
- Mixed workloads (`randrw`) are not supported because the workload name determines which side is read.
- The mean of percentiles across repeats is an approximation; for strict statistics, pool raw latency samples instead.

**Source**

```python
#!/usr/bin/env python3
"""Parse fio JSON output into one tidy CSV.

Reads every ``<rw>_bs<size>_qd<N>[_run<K>].json`` file in a directory, extracts
bandwidth, IOPS and completion-latency statistics, averages repeated runs, and
writes a CSV that ``report.py`` consumes.

Units: bandwidth in MB/s (decimal, as SSD vendors quote), latency in microseconds.

Usage:
    python scripts/parse_results.py results/raw results/summary.csv
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

import pandas as pd

NAME_RE = re.compile(r"^(?P<rw>[a-z]+)_bs(?P<bs>\w+)_qd(?P<qd>\d+)(?:_run(?P<run>\d+))?$")
PERCENTILES = {  # CSV column -> key in fio's percentile map
    "lat_p50_us": "50.000000",
    "lat_p90_us": "90.000000",
    "lat_p99_us": "99.000000",
    "lat_p999_us": "99.900000",
    "lat_p9999_us": "99.990000",
}
METRIC_COLS = ["bandwidth_MBps", "iops", "lat_avg_us", *PERCENTILES]


def bs_to_kib(bs: str) -> float:
    """'4k' -> 4, '128k' -> 128, '1m' -> 1024."""
    m = re.fullmatch(r"(\d+)([kKmM]?)", bs)
    if not m:
        raise ValueError(f"cannot parse block size: {bs!r}")
    n, unit = int(m[1]), m[2].lower()
    return float(n * 1024 if unit == "m" else n if unit == "k" else n / 1024)


def load_fio_json(path: Path) -> dict:
    """Load fio JSON, tolerating warning lines that fio prints before the object."""
    text = path.read_text()
    start = text.find("{")
    if start < 0:
        raise ValueError("no JSON object found")
    return json.loads(text[start:])


def _latency_block(side: dict) -> tuple[dict, float]:
    """Return (latency stats dict, scale-to-microseconds) for old and new fio."""
    if "clat_ns" in side:
        return side["clat_ns"], 1 / 1000.0
    if "clat" in side:  # fio < 3.0 reported microseconds
        return side["clat"], 1.0
    raise KeyError("no completion latency block")


def parse_file(path: Path) -> dict | None:
    match = NAME_RE.match(path.stem)
    if not match:
        return None
    data = load_fio_json(path)
    job = data["jobs"][0]
    if job.get("error", 0):
        raise ValueError(f"fio reported error {job['error']}")
    rw = match["rw"]
    side = job["write"] if "write" in rw else job["read"]
    lat, scale = _latency_block(side)
    pct = lat.get("percentile", {})
    row = {
        "workload": rw,
        "block_size": match["bs"],
        "block_size_kib": bs_to_kib(match["bs"]),
        "queue_depth": int(match["qd"]),
        "bandwidth_MBps": side["bw"] * 1024 / 1e6,  # fio reports KiB/s
        "iops": side["iops"],
        "lat_avg_us": lat["mean"] * scale,
        "synthetic": bool(data.get("synthetic", False)),
    }
    for col, key in PERCENTILES.items():
        row[col] = pct[key] * scale if key in pct else float("nan")
    return row


def summarize(raw_dir: Path) -> tuple[pd.DataFrame, list[str]]:
    rows, problems = [], []
    for path in sorted(raw_dir.glob("*.json")):
        if path.name == "run_metadata.json":
            continue
        try:
            row = parse_file(path)
        except Exception as exc:  # report and continue with the other files
            problems.append(f"{path.name}: {exc}")
            continue
        if row is not None:
            rows.append(row)
    if not rows:
        return pd.DataFrame(), problems

    df = pd.DataFrame(rows)
    keys = ["workload", "block_size", "block_size_kib", "queue_depth"]
    grouped = df.groupby(keys, as_index=False)
    out = grouped[METRIC_COLS].mean()
    out["runs"] = grouped.size()["size"].to_numpy()
    out["iops_std"] = grouped["iops"].std().fillna(0.0)["iops"].to_numpy()
    out["synthetic"] = grouped["synthetic"].max()["synthetic"].to_numpy()
    cols = [*keys, "runs", *METRIC_COLS, "iops_std", "synthetic"]
    return out[cols].sort_values(["workload", "block_size_kib", "queue_depth"]), problems


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("raw_dir", nargs="?", default="results/raw", help="directory of fio JSON files")
    ap.add_argument("out_csv", nargs="?", default="results/summary.csv", help="CSV to write")
    args = ap.parse_args(argv)

    raw = Path(args.raw_dir)
    if not raw.is_dir():
        print(f"error: {raw} is not a directory", file=sys.stderr)
        return 2
    df, problems = summarize(raw)
    for p in problems:
        print(f"warning: skipped {p}", file=sys.stderr)
    if df.empty:
        print(f"error: no usable fio JSON files in {raw}", file=sys.stderr)
        return 1
    Path(args.out_csv).parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(args.out_csv, index=False, float_format="%.3f")
    print(f"wrote {len(df)} rows ({int(df['runs'].sum())} runs) to {args.out_csv}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

---

## 4. `scripts/report.py`: plots, findings and reports

**Purpose.** Turn `summary.csv` into something a person can read and share: five figures, a short
list of key findings, a link-health check, and both HTML and Markdown reports.

**Usage**
```bash
python scripts/report.py results/summary.csv results/report \
    --link-info results/link_info.json --metadata results/raw/run_metadata.json \
    --title "My SSD Report"
```

**How it works**
1. Loads the CSV, `link_info.json` and `run_metadata.json` (the last two are optional; missing files are skipped).
2. Detects synthetic data from the `synthetic` column.
3. Draws five figures: sequential bandwidth vs queue depth, random IOPS vs queue depth, random p99 latency vs queue depth (log scale), p99 latency vs throughput (each point labelled with its queue depth), and a latency percentile bar chart at QD1.
4. Generates key findings from the data: peak sequential read and write bandwidth; peak random IOPS for the smallest block size; the lowest queue depth reaching 90% of peak IOPS and its p99 latency; low queue depth p50 and p99 latency; and a WARNING line for any downgraded PCIe link.
5. Writes `report.md` (with image links) and `report.html` (self-contained: images are embedded as base64, so the single file can be emailed or opened offline).

**Design decisions**
- **Consistent visual encoding.** Read is always blue and write always orange; block sizes differ by line style.
- **Latency on a log axis**, because tail latency grows quickly and a linear axis hides the low-queue-depth detail.
- **Findings are computed, not hard-coded**, so they always match the data.
- **Honest labelling.** Synthetic data gets a banner in the report and a diagonal watermark on every figure.
- Matplotlib uses the non-interactive `Agg` backend so the script runs on servers and in CI.

**Limitations**
- The "knee" is simple: the lowest queue depth with at least 90% of peak IOPS. It is a rule of thumb, not a model.
- Findings cover the smallest random block size only; the table and plots show the rest.
- One drive per report; side-by-side comparison is on the roadmap.

**Source**

```python
#!/usr/bin/env python3
"""Build plots, a markdown report and a self-contained HTML report from summary.csv.

Usage:
    python scripts/report.py results/summary.csv results/report \
        --link-info results/link_info.json --metadata results/raw/run_metadata.json
"""
from __future__ import annotations

import argparse
import base64
import html
import json
import sys
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import pandas as pd  # noqa: E402

WL_COLOR = {"read": "#2563eb", "write": "#ea580c", "randread": "#2563eb", "randwrite": "#ea580c"}
WL_LABEL = {"read": "seq read", "write": "seq write", "randread": "rand read", "randwrite": "rand write"}
LINESTYLES = ["-", "--", ":", "-."]
SEQ, RAND = ["read", "write"], ["randread", "randwrite"]
PCT_COLS = [("lat_p50_us", "p50"), ("lat_p90_us", "p90"), ("lat_p99_us", "p99"),
            ("lat_p999_us", "p99.9"), ("lat_p9999_us", "p99.99")]


# ---------------------------------------------------------------- plotting
def _groups(df: pd.DataFrame, workloads: list[str]):
    """Yield (workload, block_size, rows, linestyle) with a style per block size."""
    sub = df[df.workload.isin(workloads)]
    for wl in workloads:
        sizes = sorted(sub[sub.workload == wl].block_size_kib.unique())
        for i, kib in enumerate(sizes):
            g = sub[(sub.workload == wl) & (sub.block_size_kib == kib)].sort_values("queue_depth")
            yield wl, g.block_size.iloc[0], g, LINESTYLES[i % len(LINESTYLES)]


def _new_axes(title: str, xlabel: str, ylabel: str):
    fig, ax = plt.subplots(figsize=(7.5, 4.6))
    ax.set_title(title, fontsize=12, fontweight="bold", loc="left")
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.grid(True, alpha=0.25)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    return fig, ax


def _save(fig, path: Path, synthetic: bool) -> Path:
    if synthetic:
        fig.text(0.5, 0.5, "SYNTHETIC DEMO DATA", ha="center", va="center", fontsize=30,
                 color="gray", alpha=0.18, rotation=20, fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=160)
    plt.close(fig)
    return path


def _line_plot(df, workloads, metric, title, ylabel, path, synthetic, logy=False, scale=1.0):
    items = list(_groups(df, workloads))
    if not items:
        return None
    fig, ax = _new_axes(title, "Queue depth", ylabel)
    for wl, bs, g, ls in items:
        ax.plot(g.queue_depth, g[metric] * scale, marker="o", ms=4, lw=2, ls=ls,
                color=WL_COLOR[wl], label=f"{WL_LABEL[wl]} {bs}")
    ax.set_xscale("log", base=2)
    ax.set_xticks(sorted(df.queue_depth.unique()))
    ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    if logy:
        ax.set_yscale("log")
    ax.legend(frameon=False, fontsize=9)
    return _save(fig, path, synthetic)


def plot_latency_vs_iops(df, path, synthetic):
    items = list(_groups(df, RAND))
    if not items:
        return None
    fig, ax = _new_axes("Random p99 latency vs throughput", "Throughput (K IOPS)", "p99 latency (us)")
    for wl, bs, g, ls in items:
        ax.plot(g.iops / 1000, g.lat_p99_us, marker="o", ms=4, lw=2, ls=ls,
                color=WL_COLOR[wl], label=f"{WL_LABEL[wl]} {bs}")
        for _, r in g.iterrows():
            ax.annotate(f"QD{int(r.queue_depth)}", (r.iops / 1000, r.lat_p99_us),
                        textcoords="offset points", xytext=(4, 4), fontsize=7, color="gray")
    ax.set_yscale("log")
    ax.legend(frameon=False, fontsize=9)
    return _save(fig, path, synthetic)


def plot_percentiles(df, path, synthetic):
    g = df[df.workload == "randread"]
    if g.empty:
        return None
    g = g[g.block_size_kib == g.block_size_kib.min()]
    g = g[g.queue_depth == g.queue_depth.min()]
    cols = [(c, lab) for c, lab in PCT_COLS if c in g and g[c].notna().all()]
    if g.empty or not cols:
        return None
    row = g.iloc[0]
    fig, ax = _new_axes(f"Latency percentiles: rand read {row.block_size}, QD{int(row.queue_depth)}",
                        "Percentile", "Latency (us)")
    bars = ax.bar([lab for _, lab in cols], [row[c] for c, _ in cols], color="#2563eb", width=0.55)
    ax.bar_label(bars, fmt="%.0f", fontsize=8, padding=2)
    return _save(fig, path, synthetic)


def make_figures(df, out_dir: Path, synthetic: bool) -> dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    figs = {
        "Sequential bandwidth": _line_plot(df, SEQ, "bandwidth_MBps", "Sequential bandwidth vs queue depth",
                                           "MB/s", out_dir / "sequential_bandwidth.png", synthetic),
        "Random IOPS": _line_plot(df, RAND, "iops", "Random IOPS vs queue depth", "K IOPS",
                                  out_dir / "random_iops.png", synthetic, scale=1e-3),
        "Random p99 latency": _line_plot(df, RAND, "lat_p99_us", "Random p99 latency vs queue depth",
                                         "p99 latency (us)", out_dir / "random_p99_latency.png",
                                         synthetic, logy=True),
        "Latency vs throughput": plot_latency_vs_iops(df, out_dir / "latency_vs_iops.png", synthetic),
        "Latency percentiles": plot_percentiles(df, out_dir / "latency_percentiles.png", synthetic),
    }
    return {k: v for k, v in figs.items() if v is not None}


# ---------------------------------------------------------------- findings
def findings(df: pd.DataFrame, links: list[dict]) -> list[str]:
    out: list[str] = []
    for wl, label in [("read", "Sequential read"), ("write", "Sequential write")]:
        g = df[df.workload == wl]
        if not g.empty:
            r = g.loc[g.bandwidth_MBps.idxmax()]
            out.append(f"{label}: peak {r.bandwidth_MBps:,.0f} MB/s ({r.block_size}, QD{int(r.queue_depth)}).")
    for wl, label in [("randread", "Random read"), ("randwrite", "Random write")]:
        g = df[df.workload == wl]
        if g.empty:
            continue
        g = g[g.block_size_kib == g.block_size_kib.min()]
        peak = g.loc[g.iops.idxmax()]
        knee = g[g.iops >= 0.9 * peak.iops].sort_values("queue_depth").iloc[0]
        low = g.sort_values("queue_depth").iloc[0]
        out.append(f"{label} ({peak.block_size}): peak {peak.iops:,.0f} IOPS at QD{int(peak.queue_depth)}; "
                   f"90% of peak is reached by QD{int(knee.queue_depth)} with p99 {knee.lat_p99_us:,.0f} us "
                   f"(p99 at peak: {peak.lat_p99_us:,.0f} us).")
        out.append(f"{label} ({low.block_size}) at QD{int(low.queue_depth)}: "
                   f"p50 {low.lat_p50_us:,.0f} us, p99 {low.lat_p99_us:,.0f} us.")
    for d in links:
        if d.get("downgraded"):
            out.append(f"WARNING: {d.get('model', 'device')} ({d.get('pci_addr', '?')}) runs at "
                       f"{d.get('link_sta_speed')} {d.get('link_sta_width')} but supports "
                       f"{d.get('link_cap_speed')} {d.get('link_cap_width')}; results may be link-limited.")
    return out


# ---------------------------------------------------------------- output
def _b64(path: Path) -> str:
    return base64.b64encode(path.read_bytes()).decode()


def write_markdown(path, title, synthetic, items, links, meta, figs, df):
    lines = [f"# {title}", ""]
    if synthetic:
        lines += ["> **Synthetic demo data.** Generated by `scripts/make_demo_data.py`; not a real drive.", ""]
    lines += ["## Key findings", "", *[f"- {f}" for f in items], ""]
    if links:
        lines += ["## Device and PCIe link", "", pd.DataFrame(links).to_markdown(index=False), ""]
    if meta:
        lines += ["## Test configuration", "", *[f"- **{k}**: {v}" for k, v in meta.items()], ""]
    lines += ["## Figures", ""]
    lines += [f"![{name}]({p.name})" for name, p in figs.items()]
    show = ["workload", "block_size", "queue_depth", "runs", "bandwidth_MBps", "iops",
            "lat_avg_us", "lat_p50_us", "lat_p99_us", "lat_p999_us"]
    lines += ["", "## Data", "", df[show].round(1).to_markdown(index=False), ""]
    path.write_text("\n".join(lines))


CSS = """
body{font:15px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#1f2937}
h1{margin-bottom:.2rem} h2{margin-top:2rem;border-bottom:1px solid #e5e7eb;padding-bottom:.3rem}
.banner{background:#fef3c7;border:1px solid #f59e0b;padding:.6rem .9rem;border-radius:6px;margin:1rem 0}
.warn{color:#b91c1c;font-weight:600} table{border-collapse:collapse;font-size:13px;margin:.5rem 0}
th,td{border:1px solid #e5e7eb;padding:4px 8px;text-align:right} th{background:#f3f4f6}
td:first-child,th:first-child{text-align:left} img{max-width:100%;margin:.5rem 0}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem} @media(max-width:800px){.grid{grid-template-columns:1fr}}
"""


def write_html(path, title, synthetic, items, links, meta, figs, df):
    e = html.escape
    parts = [f"<!doctype html><html lang='en'><meta charset='utf-8'><title>{e(title)}</title>",
             f"<style>{CSS}</style><body><h1>{e(title)}</h1>"]
    if synthetic:
        parts.append("<div class='banner'><b>Synthetic demo data.</b> Generated by "
                     "<code>scripts/make_demo_data.py</code>; these are not measurements of a real drive.</div>")
    parts.append("<h2>Key findings</h2><ul>")
    parts += [f"<li class='{'warn' if f.startswith('WARNING') else ''}'>{e(f)}</li>" for f in items]
    parts.append("</ul>")
    if links:
        parts += ["<h2>Device and PCIe link</h2>", pd.DataFrame(links).to_html(index=False, border=0)]
    if meta:
        parts.append("<h2>Test configuration</h2><ul>")
        parts += [f"<li><b>{e(str(k))}</b>: {e(str(v))}</li>" for k, v in meta.items()]
        parts.append("</ul>")
    parts.append("<h2>Figures</h2><div class='grid'>")
    parts += [f"<figure style='margin:0'><img alt='{e(n)}' src='data:image/png;base64,{_b64(p)}'></figure>"
              for n, p in figs.items()]
    parts.append("</div><h2>Data</h2>")
    show = ["workload", "block_size", "queue_depth", "runs", "bandwidth_MBps", "iops",
            "lat_avg_us", "lat_p50_us", "lat_p99_us", "lat_p999_us"]
    parts.append(df[show].round(1).to_html(index=False, border=0))
    parts.append("</body></html>")
    path.write_text("\n".join(parts))


def _load_json(path: str | None, default):
    if path and Path(path).is_file():
        try:
            return json.loads(Path(path).read_text())
        except json.JSONDecodeError as exc:
            print(f"warning: could not read {path}: {exc}", file=sys.stderr)
    return default


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("summary", nargs="?", default="results/summary.csv")
    ap.add_argument("out_dir", nargs="?", default="results/report")
    ap.add_argument("--link-info", default="results/link_info.json")
    ap.add_argument("--metadata", default="results/raw/run_metadata.json")
    ap.add_argument("--title", default="NVMe SSD Performance Report")
    args = ap.parse_args(argv)

    if not Path(args.summary).is_file():
        print(f"error: {args.summary} not found (run parse_results.py first)", file=sys.stderr)
        return 2
    df = pd.read_csv(args.summary)
    synthetic = bool(df["synthetic"].any()) if "synthetic" in df else False
    links = _load_json(args.link_info, [])
    meta = _load_json(args.metadata, {})
    meta = {k: v for k, v in meta.items() if k not in ("synthetic", "hostname")}

    out = Path(args.out_dir)
    figs = make_figures(df, out, synthetic)
    items = findings(df, links)
    write_markdown(out / "report.md", args.title, synthetic, items, links, meta, figs, df)
    write_html(out / "report.html", args.title, synthetic, items, links, meta, figs, df)
    print(f"report written to {out} (report.html, report.md, {len(figs)} figures)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
```

---

## 5. `scripts/make_demo_data.py`: SYNTHETIC demo data

**Purpose.** Let anyone try the whole pipeline, and let CI test it, without owning a drive. The files
mimic fio's JSON layout so the real parser and report run unmodified.

**These are not measurements.** Every file has `"synthetic": true`, and the report and figures say so.
Never present this data as results from a real SSD.

**Usage**
```bash
python scripts/make_demo_data.py demo/raw --repeats 3
```

**How it works**
1. Builds the same plan as the real sweep: sequential 128 KiB, random 4 KiB and 16 KiB, queue depths 1, 4, 16 and 32.
2. Models throughput with a saturating curve. Sequential bandwidth approaches a plateau as queue depth rises; random IOPS approach a peak that falls with block size.
3. Derives latency from queue depth and IOPS using Little's law (latency = queue depth / IOPS), then spreads percentiles above the mean with a tail factor that grows with queue depth.
4. Adds about 1.5% random noise per run, from a fixed seed so results are reproducible.
5. Writes fio-style JSON per run, plus `run_metadata.json` and a demo `link_info.json` for a fictional drive.

**Design decisions**
- Internal consistency (bandwidth = IOPS x block size, latency from Little's law) makes the demo plots look plausible and exercises the same code paths as real data.
- Deterministic output keeps tests stable.

**Source**

```python
#!/usr/bin/env python3
"""Generate SYNTHETIC fio-format JSON so the toolkit can be tried without a drive.

Every file carries ``"synthetic": true`` and the report shows a banner and a
watermark. These are NOT measurements of any real SSD. The model keeps the
numbers internally consistent (latency follows Little's law: QD / IOPS).

Usage:
    python scripts/make_demo_data.py demo/raw --repeats 3
"""
from __future__ import annotations

import argparse
import json
import math
import random
from pathlib import Path

SEQ_PLATEAU_MBPS = {"read": 3500.0, "write": 3000.0}
RAND_PEAK_4K_IOPS = {"randread": 650_000.0, "randwrite": 560_000.0}
SEQ_BS_KIB = 128
RAND_BS_KIB = [4, 16]
QUEUE_DEPTHS = [1, 4, 16, 32]


def point(rw: str, bs_kib: int, qd: int, rng: random.Random) -> dict:
    bs_bytes = bs_kib * 1024
    if rw in SEQ_PLATEAU_MBPS:
        bw_mbps = SEQ_PLATEAU_MBPS[rw] * (1 - math.exp(-qd / 1.5))
        iops = bw_mbps * 1e6 / bs_bytes
    else:
        iops = RAND_PEAK_4K_IOPS[rw] * (4 / bs_kib) ** 0.85 * (1 - math.exp(-qd / 9))
        bw_mbps = iops * bs_bytes / 1e6
    noise = rng.gauss(1.0, 0.015)
    iops *= noise
    bw_mbps *= noise
    mean_ns = qd / iops * 1e9  # Little's law
    tail = 1 + 0.04 * qd
    return {
        "bw": bw_mbps * 1e6 / 1024,  # KiB/s, as fio reports
        "iops": iops,
        "clat_ns": {
            "mean": mean_ns,
            "percentile": {
                "50.000000": mean_ns * 0.92,
                "90.000000": mean_ns * 1.35 * tail ** 0.3,
                "99.000000": mean_ns * 1.9 * tail ** 0.7,
                "99.900000": mean_ns * 3.2 * tail,
                "99.990000": mean_ns * 6.0 * tail * 1.4,
            },
        },
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("out_dir", nargs="?", default="demo/raw")
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--seed", type=int, default=7)
    args = ap.parse_args()

    out = Path(args.out_dir)
    out.mkdir(parents=True, exist_ok=True)
    rng = random.Random(args.seed)
    empty = {"bw": 0, "iops": 0, "clat_ns": {"mean": 0, "percentile": {}}}

    plan = []
    for qd in QUEUE_DEPTHS:
        plan += [("read", SEQ_BS_KIB, qd), ("write", SEQ_BS_KIB, qd)]
        for bs in RAND_BS_KIB:
            plan += [("randread", bs, qd), ("randwrite", bs, qd)]

    for run in range(1, args.repeats + 1):
        for rw, bs, qd in plan:
            side = point(rw, bs, qd, rng)
            job = {"jobname": f"{rw}_{bs}k_qd{qd}", "error": 0,
                   "read": side if "write" not in rw else empty,
                   "write": side if "write" in rw else empty}
            doc = {"fio version": "synthetic-demo", "synthetic": True, "jobs": [job]}
            (out / f"{rw}_bs{bs}k_qd{qd}_run{run}.json").write_text(json.dumps(doc, indent=1))

    (out / "run_metadata.json").write_text(json.dumps({
        "timestamp_utc": "2026-01-01T00:00:00Z", "hostname": "demo-host", "kernel": "demo",
        "fio_version": "synthetic-demo", "target": "/mnt/nvme/fio_testfile (synthetic)",
        "target_type": "file", "size": "4G", "runtime_s": 30, "ramp_s": 5, "seq_bs": "128k",
        "rand_bs": "4k 16k", "queue_depths": "1 4 16 32", "repeats": args.repeats,
        "ioengine": "libaio", "synthetic": True}, indent=2))
    (out.parent / "link_info.json").write_text(json.dumps([{
        "pci_addr": "0000:01:00.0", "model": "DEMO NVMe SSD 1TB (synthetic)",
        "link_cap_speed": "16GT/s", "link_cap_width": "x4",
        "link_sta_speed": "16GT/s", "link_sta_width": "x4",
        "downgraded": False, "temperature_c": 41}], indent=2))
    print(f"wrote synthetic demo data to {out}")


if __name__ == "__main__":
    main()
```

---

## Supporting files

| File | Purpose |
|---|---|
| `Makefile` | `make demo` runs the synthetic pipeline and refreshes `docs/`; `make test` runs unit tests; `make lint` runs shellcheck |
| `tests/test_parse_results.py` | Unit conversion, write/read side selection, noisy fio output, repeat averaging, error handling |
| `tests/test_report.py` | Report files are created, downgraded links raise a WARNING, missing input returns an error |
| `.github/workflows/ci.yml` | Runs shellcheck, tests and the demo on every push |
| `requirements.txt` | `pandas`, `matplotlib`, `tabulate` |

## Verification status (be honest about this in your write-up)
- Unit tests: 10 passing, run in the development environment.
- `parse_results.py`, `report.py`, `make_demo_data.py`: exercised end to end on synthetic data.
- `run_benchmarks.sh` and `link_info.sh`: exercised only with stand-ins for `fio` and `lspci`. They have not run against a real drive. Run them on your hardware, compare against fio's console output and `lspci -vv`, and fix anything that differs on your system before you quote results.
- shellcheck was not available in the development environment; CI runs it.

## Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `fio not found` | fio not installed | `sudo apt install fio` |
| `lspci not found` | pciutils missing | `sudo apt install pciutils` |
| Link fields blank in `link_info` | Not running as root | Re-run with `sudo` |
| `not enough free space` | Test file larger than free space | Lower `--size` or free space |
| `refusing to continue` (mounted) | Block device has a mounted filesystem | Use a test file, or unmount a scratch drive |
| Parser says "no usable fio JSON files" | Wrong directory or renamed files | Point at the raw folder; keep original names |
| Percentile columns empty | Older fio, or percentiles not requested | Use the sweep script as written; update fio |
| Results far below the drive rating | Link downgrade, throttling, SLC cache | See the README technical note |
